import ChatPage from './pages/ChatPage';

function App() {
  return (
    <div className="App">
      <h1>Critical Thinking AI</h1>
      <ChatPage />
    </div>
  );
}

export default App;
