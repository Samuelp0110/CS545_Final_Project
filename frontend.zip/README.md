# Project synopsis here

To start the project, run this command in the root folder in a linux environment:

./run_local.sh
